class HashError(Exception):
    pass


class ModDBDownloadError(Exception):
    pass
