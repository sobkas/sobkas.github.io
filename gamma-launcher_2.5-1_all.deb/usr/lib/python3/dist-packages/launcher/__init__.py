__title__ = "gamma-launcher"
__version__ = "2.5"
